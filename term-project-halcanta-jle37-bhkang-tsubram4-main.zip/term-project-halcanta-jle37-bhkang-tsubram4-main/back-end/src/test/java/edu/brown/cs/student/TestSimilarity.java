package edu.brown.cs.student;

import static org.junit.Assert.*;

import edu.brown.cs.student.main.similarityalg.CourseSimilarity;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;

/** Class to test similarity algorithm */
public class TestSimilarity {

  private CourseSimilarity courseSimilarity;

  @Before
  public void setUp() throws IOException {
    String filePath =
        "/Users/habramalcantar/Desktop/CS320/term-project-halcanta-jle37-bhkang-tsubram4/scraper/data/full_cab_04_20_23:00.json";
    String jsonInput = new String(Files.readAllBytes(Paths.get(filePath)));
    JSONObject jsonData = new JSONObject(jsonInput);
    courseSimilarity = new CourseSimilarity(jsonData);
  }

  @Test
  public void testSimilarityWithUniqueKeyword() {
    JSONObject scores = courseSimilarity.calculateSimilarityAndModifyJson("Arabic");
    double index1 = scores.getJSONArray("ARAB").getJSONObject(0).getDouble("similarity_index");
    double index2 = scores.getJSONArray("ARAB").getJSONObject(1).getDouble("similarity_index");
    double index3 = scores.getJSONArray("ARAB").getJSONObject(2).getDouble("similarity_index");
    double index4 = scores.getJSONArray("ARAB").getJSONObject(3).getDouble("similarity_index");
    assertTrue(index1 > 0);
    assertTrue(index2 > 0);
    assertTrue(index3 > 0);
    assertTrue(index4 > 0);
  }

  @Test
  public void testSimilarityWithNoOccurrences() {
    JSONObject scores = courseSimilarity.calculateSimilarityAndModifyJson("randomword123");
    double index = scores.getJSONArray("AFRI").getJSONObject(0).getDouble("similarity_index");
    assertEquals(0, index, 0.001);
  }
}
