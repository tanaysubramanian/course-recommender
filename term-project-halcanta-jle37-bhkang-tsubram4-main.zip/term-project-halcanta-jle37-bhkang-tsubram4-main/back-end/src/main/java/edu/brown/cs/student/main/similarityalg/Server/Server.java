package edu.brown.cs.student.main.similarityalg;

import static spark.Spark.after;

import java.io.FileNotFoundException;
import spark.Spark;

public class Server {
  /**
   * The initial method called when execution begins.
   *
   * @param args An array of command line arguments
   */
  public static void main(String[] args) throws FileNotFoundException {
    new Server(args).run();
  }

  static SearchState currentState;

  private Server(String[] args) {}

  public void run() {
    // start up a port
    int port = 3232;
    Spark.port(port);
    // set up the shared dataclass
    currentState = new SearchState();

    after(
        (request, response) -> {
          response.header("Access-Control-Allow-Origin", "*");
          response.header("Access-Control-Allow-Methods", "*");
        });

    // courseSearch endpoint set up
    Spark.get("courseSearch", new CourseSearchHandler(currentState));
    Spark.init();
    Spark.awaitInitialization();

    System.out.println("Server started at http://localhost:" + port);
  }
}
