package edu.brown.cs.student.main.similarityalg;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

public class CourseSimilarity {

  private JSONObject coursesJson;

  /** initializes a CourseSimilarity Object */
  public CourseSimilarity(JSONObject jsonData) {
    this.coursesJson = jsonData;
  }

  /** retrieves the names of inctructors for past courses inputted by user */
  public Set<String> getInstructorsFromPastCourses(String[] pastCourses) {
    Set<String> pastInstructors = new HashSet<>();
    for (String courseCode : pastCourses) {
      for (Object deptKey : coursesJson.keySet()) {
        JSONArray deptCourses = coursesJson.getJSONArray((String) deptKey);
        for (int i = 0; i < deptCourses.length(); i++) {
          JSONObject courseObj = deptCourses.getJSONObject(i);
          if (courseObj.getString("class_code").equals(courseCode)) {
            JSONArray instructors = courseObj.getJSONArray("class_instructors");
            for (int j = 0; j < instructors.length(); j++) {
              pastInstructors.add(instructors.getJSONObject(j).getString("name"));
            }
            break;
          }
        }
      }
    }
    return pastInstructors;
  }

  /**
   * function that determines whether or not the course meets the time requirements the user wants
   * by comparing times the class is held
   */
  public ArrayList<String> filterByTimes(ArrayList<String> listFilteredByDays, String[] times) {
    ArrayList<String> desiredTimesAndDays = new ArrayList<String>();

    if (listFilteredByDays.size() == 0 || times[0].equals("")) {
      return listFilteredByDays;
    }

    for (String prevFilter : listFilteredByDays) {
      for (String t : times) {
        switch (t) {
            // Before 12pm checks for times between 8:00am-11:59pm
          case "Before 12pm":
            if ((prevFilter.contains("8:")
                    || prevFilter.contains("9:")
                    || prevFilter.contains("10:")
                    || prevFilter.contains("11:"))
                && !desiredTimesAndDays.contains(prevFilter)) {
              desiredTimesAndDays.add(prevFilter);
            }
            break;
            // checks for times between 12:00pm-3:59pm
          case "12pm-4pm":
            if ((prevFilter.contains("12:")
                    || prevFilter.contains("1:")
                    || prevFilter.contains("2:")
                    || prevFilter.contains("3:"))
                && !desiredTimesAndDays.contains(prevFilter)) {
              desiredTimesAndDays.add(prevFilter);
            }
            break;
            // checks for times between 4:00pm-6:59pm
          case "4pm-6pm":
            if ((prevFilter.contains("4:")
                    || prevFilter.contains("5:")
                    || prevFilter.contains("6:"))
                && !desiredTimesAndDays.contains(prevFilter)) {
              desiredTimesAndDays.add(prevFilter);
            }
            break;
            // checks for times between 7:00pm-9:59pm
          case "After 6pm":
            if ((prevFilter.contains("7:")
                    || prevFilter.contains("8:")
                    || prevFilter.contains("9:"))
                && !desiredTimesAndDays.contains(prevFilter)) {
              desiredTimesAndDays.add(prevFilter);
            }
            break;
        }
      }
    }
    return desiredTimesAndDays;
  }

  /**
   * function that determines whether or not the course meets the time requirements the user wants
   * by comparing days the class is held
   */
  public ArrayList<String> filterByDay(JSONObject course, String[] days, String[] times) {
    ArrayList<String> desiredSections = new ArrayList<String>();
    JSONArray classMeetingTimes = course.getJSONArray("class_sections");

    if (classMeetingTimes.get(0).equals("Sections TBD or not available.")) {
      return desiredSections;
    }

    if (days[0].equals("") && times[0].equals("")) {
      for (int i = 0; i < classMeetingTimes.length(); i++) {
        JSONObject meetingTime = classMeetingTimes.getJSONObject(i);
        String mTimes = meetingTime.getString("section_meets");
        String sectionType = meetingTime.getString("section_num");
        if (sectionType.contains("S")) {
          desiredSections.add(mTimes);
        }
      }
      return desiredSections;
    } else if (days[0].equals("") && !(times[0].equals(""))) {
      for (int i = 0; i < classMeetingTimes.length(); i++) {
        JSONObject meetingTime = classMeetingTimes.getJSONObject(i);
        String mTimes = meetingTime.getString("section_meets");
        String sectionType = meetingTime.getString("section_num");
        if (sectionType.contains("S")) {
          desiredSections.add(mTimes);
        }
      }
      return filterByTimes(desiredSections, times);
    } else {
      for (int i = 0; i < classMeetingTimes.length(); i++) {
        JSONObject meetingTime = classMeetingTimes.getJSONObject(i);
        String mTimes = meetingTime.getString("section_meets");
        String sectionType = meetingTime.getString("section_num");
        for (String dayOfWeek : days) {
          if (sectionType.contains("S") && mTimes.contains(dayOfWeek)) {
            desiredSections.add(mTimes);
          }
        }
      }
      return filterByTimes(desiredSections, times);
    }
  }

  /**
   * function calculateSimilarityAndModifyJson compares the CAB JSONdata with the user input to find
   * calculate a similarity score and return the best matches as an array of array of strings
   */
  public ArrayList<ArrayList<String>> calculateSimilarityAndModifyJson(
      String keyword,
      String[] pastCourses,
      Boolean prioritizeInstructor,
      String[] allDaysOfWeek,
      String[] allTimes) {
    Set<String> pastInstructors = getInstructorsFromPastCourses(pastCourses);
    Set<String> pastDepts = new HashSet<>();
    ArrayList<ArrayList<String>> courseList = new ArrayList<ArrayList<String>>();

    for (String courseCode : pastCourses) {
      pastDepts.add(courseCode.split(" ")[0]);
    }

    // iterates through JSON and assigns values to each component of a course
    for (Object deptKey : coursesJson.keySet()) {
      JSONArray deptCourses = coursesJson.getJSONArray((String) deptKey);
      for (int i = 0; i < deptCourses.length(); i++) {
        ArrayList course = new ArrayList<String>();
        JSONObject courseObj = deptCourses.getJSONObject(i);
        String classDepartment = courseObj.getString("class_dept");
        String classTitle = courseObj.getString("class_title").toLowerCase();
        String classCode = courseObj.getString("class_code");
        String classDescription = courseObj.getString("class_description").toLowerCase();
        String classRestrictions = courseObj.getString("class_reg_restrictions");
        String combinedText = classTitle + " " + classDescription;
        int totalWords = combinedText.split("\\s+").length;
        int keywordFrequency =
            (combinedText.split("\\b" + keyword.toLowerCase() + "\\b", -1).length) - 1;
        float similarity = totalWords > 0 ? (float) keywordFrequency / totalWords : 0;

        if (prioritizeInstructor) {
          JSONArray instructors = courseObj.getJSONArray("class_instructors");
          for (int j = 0; j < instructors.length(); j++) {
            Object instructorObj = instructors.get(j);
            if (instructorObj instanceof JSONObject) {
              String instructorName = ((JSONObject) instructorObj).getString("name");
              System.out.println(instructorName);
              if (pastInstructors.contains(instructorName)) {
                similarity += 0.3;
                break;
              }
            }
          }
        } else {
          if (pastDepts.contains(classDepartment)) {
            similarity += 0.2;
          }
        }

        ArrayList<String> desiredDaysAndTimes = filterByDay(courseObj, allDaysOfWeek, allTimes);

        // adds a course only if it meets the threshold
        if (similarity > 0.01 && desiredDaysAndTimes.size() != 0) {
          course.add(classDepartment);
          course.add(classTitle);
          course.add(classCode);
          course.add(classDescription);
          course.add(classRestrictions);
          String times = "";
          for (String s : desiredDaysAndTimes) {
            times = times + s + ", ";
          }
          course.add(times.substring(0, times.length() - 2));
          times = "";
          course.add(Float.toString(similarity));
          courseList.add(course);
        }
      }
    }
    return courseList;
  }
}
