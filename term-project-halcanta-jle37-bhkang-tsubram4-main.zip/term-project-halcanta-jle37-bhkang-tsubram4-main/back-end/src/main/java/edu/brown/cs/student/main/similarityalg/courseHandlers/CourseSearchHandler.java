package edu.brown.cs.student.main.similarityalg;

import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;
import com.squareup.moshi.Types;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.ArrayList;
import java.util.Map;
import org.json.JSONObject;
import spark.Request;
import spark.Response;
import spark.Route;

/** This is the handler for the "/courseSearch" endpoint. It takes in a filepath to parse/load. */
public class CourseSearchHandler implements Route {

  private final SearchState state;

  public CourseSearchHandler(SearchState state) {
    this.state = state;
  }

  /**
   * Requests a filepath query to load from user adn calls on parse
   *
   * @param request
   * @param response
   * @return either loadfailresponse or loadsuccessresponse
   * @throws Exception
   */
  @Override
  public Object handle(Request request, Response response) throws Exception {
    // here we will call our parse,

    Moshi moshi = new Moshi.Builder().build();
    Type mapStringObject = Types.newParameterizedType(Map.class, String.class, Object.class);
    JsonAdapter<Map<String, Object>> adapter = moshi.adapter(mapStringObject);
    Map<String, Object> responseMap = new HashMap<>();

    String keyword = request.queryParams("keyword");
    String pastCourses = request.queryParams("pastCourses");
    String prioritizeQuery = request.queryParams("prioritizeQuery");
    String dayOfWeek = request.queryParams("dayOfWeek");
    String timesOfWeek = request.queryParams("timesOfWeek");

    // splits on underscores to distinguish between multiple entries
    String[] allPastCourses = pastCourses.split("_");
    String[] allDaysOfWeek = dayOfWeek.split("_");
    String[] allTimesOfWeek = timesOfWeek.split("_");

    Boolean pQuery = Boolean.parseBoolean(prioritizeQuery);
    String content =
        new String(
            Files.readAllBytes(
                Paths.get(
                    "/Users/habramalcantar/Desktop/CS320/term-project-halcanta-jle37-bhkang-tsubram4/scraper/data/full_cab_04_20_23:00.json")));
    JSONObject jsonData = new JSONObject(content);
    CourseSimilarity cs = new CourseSimilarity(jsonData);
    ArrayList<ArrayList<String>> responseData =
        cs.calculateSimilarityAndModifyJson(
            keyword, allPastCourses, pQuery, allDaysOfWeek, allTimesOfWeek);
    responseMap.put("result", "success");
    responseMap.put("info", responseData);
    return adapter.toJson(responseMap);
  }
}
