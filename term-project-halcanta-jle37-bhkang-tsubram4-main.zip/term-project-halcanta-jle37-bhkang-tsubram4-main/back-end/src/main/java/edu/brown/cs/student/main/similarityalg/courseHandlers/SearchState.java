package edu.brown.cs.student.main.similarityalg;

import java.util.ArrayList;
import java.util.List;

/**
 * Class representing the shared state for user search calls. Contains a filepath, loaded state, and
 * results.
 */
public class SearchState {

  private String keyword = "";
  private List<List<String>> loadResults = new ArrayList<>();
  private State currState = State.EMPTY;

  public enum State {
    LOADED,
    FAILED,
    EMPTY;
  }

  public SearchState() {}

  public void searchSuccess() {
    this.currState = State.LOADED;
  }

  public void searchFailed() {
    this.currState = State.FAILED;
  }

  public void setKeyword(String newWord) {
    this.keyword = newWord;
  }

  public void setResults(List<List<String>> results) {
    this.loadResults = results;
  }

  public State getState() {
    return this.currState;
  }

  public String getKeyword() {
    return this.keyword;
  }

  public List<List<String>> getLoadResults() {
    return this.loadResults;
  }
}
