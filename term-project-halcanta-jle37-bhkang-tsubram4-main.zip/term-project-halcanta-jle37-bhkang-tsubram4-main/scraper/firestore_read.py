import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import json
import re


cred = credentials.Certificate('./firebase_config.json')
app = firebase_admin.initialize_app(cred)
db = firestore.client()

def read_all_from_dept(class_dept):
    dept_class_arr = []
    dept_ref = db.collection(class_dept)
    dept_classes = dept_ref.stream()
    for dept_class in dept_classes:
        dept_class_arr.append(dept_class.to_dict())

    # prints the returned arr so you can see
    print(json.dumps(dept_class_arr, indent=4))
    return dept_class_arr

def read_class_by_code(class_code:str):
    """
    returns a single-element array containing a hashmap of the class_code's information
    """
    class_obj_arr = []
    match = re.match(r"([A-Z]+)\s", class_code)
    if match:
        class_dept =  match.group(1).strip()
    else:
        class_dept = "error"
    class_ref = db.collection(class_dept).where('class_code', '==', class_code).stream()
    for ref in class_ref:
        class_obj = ref.to_dict()
        # print(json.dumps(class_obj, indent=4))
        class_obj_arr.append(class_obj)
    
    if len(class_obj_arr) > 1:
        print("WARNING, malformed array with more than one class despite single class read, returned array has length: "+str(len(class_obj_arr)))
    return class_obj_arr


# example of retrieval of a dept array
example_arr = read_all_from_dept("ARAB")
# example of how to retrieve a specific field from 
# the returned array, here ARAB 0100 description
print(example_arr[1]["class_description"])


# example of retrieval by class code (ARAB 500)
example_class = read_class_by_code("ARAB 0500")
# example of how to retrieve a specific field from 
# the returned object, here ARAB 0500 description
# NOTE: WE SHOULD ALWAYS BE RETRIVING BY INDEX 0, I JUST 
# RETURN IT AS A 1-OBJ ARRAY FOR ERROR/SAFETY REASONS
print(example_class[0]["class_description"])