import json

def extract_keys_from_json(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)
    
    keys = list(data.keys())
    print("Outermost keys in the JSON file:", keys)

extract_keys_from_json('./scraper/data/full_cab_04_20_23:00.json')
