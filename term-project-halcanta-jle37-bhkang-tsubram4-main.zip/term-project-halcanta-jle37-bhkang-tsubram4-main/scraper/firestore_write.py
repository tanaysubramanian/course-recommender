import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import json


cred = credentials.Certificate('./firebase_config.json')
app = firebase_admin.initialize_app(cred)
db = firestore.client()


def write_to_db_from_file(file_name):
    data = "noneLoaded"
    with open(f"./data/{file_name}.json") as sample:
        data = json.load(sample)

    # print(data)
    if data != "noneLoaded":
        for class_dept, class_arr in data.items():
            for class_obj in class_arr:
                class_code = class_obj["class_code"]
                doc_ref = db.collection(class_dept).document(class_code)
                doc_ref.set(class_obj)
                print(f"added class: {class_code} to db")


write_to_db_from_file("full_cab_04_20_23:00")