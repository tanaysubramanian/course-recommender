import json
import pytest

def load_json(filepath):
    with open(filepath, 'r') as file:
        return json.load(file)

# fp_orig = './data/sample1.json'
# fp_test = './data/panel_body1.json'

# fp_orig = './data/sample4.json'
# fp_test = './data/panel_body4.json'

fp_orig = './data/sample5_sans_anth.json'
fp_test = './data/panel_body5_sans_anth.json'

scrape_targeted = load_json(fp_orig)
scrape_body = load_json(fp_test)


def test_course_codes_correct():
    for dept, courses in scrape_targeted.items():
        for course in courses:
            try:
                assert course["class_code"] != "Course code not found."
            except AssertionError as e:
                print(f"CLASSCODE assertion error for course in {dept} department, {e}")
                print("ERRONEOUS COURSE:")
                json_dict = json.dumps(course, indent=4)
                print(json_dict)
                raise

def test_class_titles_correct():
    for dept, courses in scrape_targeted.items():
        for course in courses:
            try:
                assert course["class_title"] != "Class title not found."
            except AssertionError as e:
                print(f"TITLES assertion error for course in {dept} department, {e}")
                print("ERRONEOUS COURSE:")
                json_dict = json.dumps(course, indent=4)
                print(json_dict)
                raise

# Checks classes with "description not found" and validates that these courses truly do not have a description
def test_descriptions_correct():
    for dept, courses in scrape_targeted.items():
        for course in courses:
            if course["class_description"] == "Description not found.":
                for body_course in scrape_body[dept]:
                    if body_course["class_code"] == course["class_code"]:
                        try:
                            assert "Course Description" not in body_course["class_body"], "ERROR: missed description scrape"
                        except AssertionError as e:
                            print(f"DESCRIPTION assertion error for course in {dept} department, {e}")
                            print("ERRONEOUS COURSE:")
                            json_dict = json.dumps(course, indent=4)
                            print(json_dict)
                            raise

# Checks classes with "Registration restrictions not found/provided" and validates that these courses truly do not have restrictions to scrape
def test_registration_correct():
    for dept, courses in scrape_targeted.items():
        for course in courses:
            if course["class_reg_restrictions"] == "Registration restrictions not found/provided.":
                for body_course in scrape_body[dept]:
                    if body_course["class_code"] == course["class_code"]:
                        try:
                            assert "Registration Restrictions" not in body_course["class_body"], "ERROR: missed registration restrictions scrape"
                        except AssertionError as e:
                            print(f"RESTRICTIONS assertion error for course in {dept} department, {e}")
                            print("ERRONEOUS COURSE:")
                            json_dict = json.dumps(course, indent=4)
                            print(json_dict)
                            raise


# print(scrape_targeted)
# print(scrape_targeted["ARAB"])
# json_dict = json.dumps(scrape_targeted, indent=4)
# print(json_dict)
"""
pytest scrape_testing.py
"""