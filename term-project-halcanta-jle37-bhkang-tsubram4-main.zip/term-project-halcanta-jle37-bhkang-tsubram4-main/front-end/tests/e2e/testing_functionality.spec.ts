import {expect, test} from "@playwright/test"

const url = "http://localhost:8000"

test("successfully able to make a keyword search w/o any other parameters", async ({page}) => {
    await page.goto(url);

    // making sure the search bar is visible
    await expect(page.getByLabel('Searchbar')).toBeVisible();
    await expect(page.getByPlaceholder("Enter command here!")).toBeVisible();

    // clicking on the search bar
    await page.getByPlaceholder("Enter command here!").click();

    // entering a keyword into the search bar
    await page.getByPlaceholder("Enter command here!").fill("poetry");

    // making sure the "submit" button is visible
    await expect(page.getByLabel("Query Submit Button")).toBeVisible();

    // entering the query
    await page.getByLabel("Query Submit Button").click();

    // making sure a result is produced
    await expect(page.getByText("Recommended Courses For Keyword: poetry ✿ ʕ •ᴥ•ʔ")).toBeVisible();
    let string = "You've Reached The End Of Our Recommended Courses for the Keyword: poetry ᕦʕ •`ᴥ•´ʔᕤ"
    await expect(page.getByText(string)).toBeVisible();
})

test("successfully able to make a search based on day of the week w/o any other parameters", async ({page}) => {
    await page.goto(url);

    // making sure the Monday button is visible
    await expect(page.getByLabel('Monday Button')).toBeVisible();

    // clicking on the Monday button
    await page.getByLabel("Monday Button").click();

    // making sure the "submit" button is visible
    await expect(page.getByLabel("Query Submit Button")).toBeVisible();

    // entering the query
    await page.getByLabel("Query Submit Button").click();

    // making sure a result is produced
    await expect(page.getByText("Recommended Courses For Keyword: ✿ ʕ •ᴥ•ʔ")).toBeVisible();
    let string = "You've Reached The End Of Our Recommended Courses for the Keyword: ᕦʕ •`ᴥ•´ʔᕤ"
    await expect(page.getByText(string)).toBeVisible();
})

test("successfully able to make a search based on time of day w/o any other parameters", async ({page}) => {
    await page.goto(url);

    // making sure the Early Morning button is visible
    await expect(page.getByText('Early Morning')).toBeVisible();

    // clicking on the Early Morning button
    await page.getByText('Early Morning').click();

    // making sure the "submit" button is visible
    await expect(page.getByLabel("Query Submit Button")).toBeVisible();

    // entering the query
    await page.getByLabel("Query Submit Button").click();

    // making sure a result is produced
    await expect(page.getByText("Recommended Courses For Keyword: ✿ ʕ •ᴥ•ʔ")).toBeVisible();
    let string = "You've Reached The End Of Our Recommended Courses for the Keyword: ᕦʕ •`ᴥ•´ʔᕤ"
    await expect(page.getByText(string)).toBeVisible();
})

test("successfully able to make a search based on a past course w/o any other parameters", async ({page}) => {
    await page.goto(url);

    // selecting a department from the drop down
    await page.locator("#department").selectOption({label: "CSCI"});

    // selecting a course code from the drop down
    await page.locator("#course").selectOption({label: "CSCI 0320"});

    // making sure the Add Course button is visible
    await expect(page.getByLabel("Past Course Submit Button")).toBeVisible();

    // clicking on the Add Course button
    await page.getByLabel("Past Course Submit Button").click();

    // making sure the "submit" button is visible
    await expect(page.getByLabel("Query Submit Button")).toBeVisible();

    // entering the query
    await page.getByLabel("Query Submit Button").click();

    // making sure a result is produced
    await expect(page.getByText("Recommended Courses For Keyword: ✿ ʕ •ᴥ•ʔ")).toBeVisible();
    let string = "You've Reached The End Of Our Recommended Courses for the Keyword: ᕦʕ •`ᴥ•´ʔᕤ"
    await expect(page.getByText(string)).toBeVisible();
})

test("successfully able to make a search based on multiple past courses", async ({page}) => {
    await page.goto(url);

    // selecting a department from the drop down
    await page.locator("#department").selectOption({label: "VISA"});

    // selecting a course code from the drop down
    await page.locator("#course").selectOption({label: "VISA 0100"});

    // making sure the Add Course button is visible
    await expect(page.getByLabel("Past Course Submit Button")).toBeVisible();

    // clicking on the Add Course button
    await page.getByLabel("Past Course Submit Button").click();

    // selecting a department from the drop down again
    await page.locator("#department").selectOption({label: "CSCI"});

    // selecting a course code from the drop down again
    await page.locator("#course").selectOption({label: "CSCI 0320"});

    // making sure the Add Course button is visible again
    await expect(page.getByLabel("Past Course Submit Button")).toBeVisible();

    // clicking on the Add Course button again
    await page.getByLabel("Past Course Submit Button").click();

    // making sure the "submit" button is visible 
    await expect(page.getByLabel("Query Submit Button")).toBeVisible();

    // entering the query
    await page.getByLabel("Query Submit Button").click();

    // making sure a result is produced
    await expect(page.getByText("Recommended Courses For Keyword: ✿ ʕ •ᴥ•ʔ")).toBeVisible();
    let string = "You've Reached The End Of Our Recommended Courses for the Keyword: ᕦʕ •`ᴥ•´ʔᕤ"
    await expect(page.getByText(string)).toBeVisible();
})

test("successfully able to make a search based on a keyword, then clear the course recommendations", async ({page}) => {
    await page.goto(url);

    // making sure the search bar is visible
    await expect(page.getByLabel('Searchbar')).toBeVisible();

    // clicking on the search bar
    await page.getByPlaceholder("Enter command here!").click();

    // entering a keyword into the search bar
    await page.getByPlaceholder("Enter command here!").fill("visa");

    // making sure the "submit" button is visible 
    await expect(page.getByLabel("Query Submit Button")).toBeVisible();

    // entering the query
    await page.getByLabel("Query Submit Button").click();

    // making sure a result is produced
    await expect(page.getByText("Recommended Courses For Keyword: visa ✿ ʕ •ᴥ•ʔ")).toBeVisible();
    let string = "You've Reached The End Of Our Recommended Courses for the Keyword: visa ᕦʕ •`ᴥ•´ʔᕤ"
    await expect(page.getByText(string)).toBeVisible();

    // making sure the "reset history" button is visible
    await expect(page.getByLabel("Clear History Button")).toBeVisible();

    // clicking on the "reset history" button
    await page.getByLabel("Clear History Button").click();

    // making sure that the output has been cleared
    await expect(page.getByText("Recommended Courses For Keyword: visa ✿ ʕ •ᴥ•ʔ")).not.toBeVisible();
    await expect(page.getByText(string)).not.toBeVisible();
})

test("successfully able to make a multiple successive keyword queries", async ({page}) => {
    await page.goto(url);

    // making sure the search bar is visible
    await expect(page.getByLabel('Searchbar')).toBeVisible();

    // clicking on the search bar
    await page.getByPlaceholder("Enter command here!").click();

    // entering a keyword into the search bar
    await page.getByPlaceholder("Enter command here!").fill("visa");

    // making sure the "submit" button is visible 
    await expect(page.getByLabel("Query Submit Button")).toBeVisible();

    // entering the query
    await page.getByLabel("Query Submit Button").click();

    // making sure a result is produced
    await expect(page.getByText("Recommended Courses For Keyword: visa ✿ ʕ •ᴥ•ʔ")).toBeVisible();
    let string = "You've Reached The End Of Our Recommended Courses for the Keyword: visa ᕦʕ •`ᴥ•´ʔᕤ"
    await expect(page.getByText(string)).toBeVisible();

    // clicking on the search bar again
    await page.getByPlaceholder("Enter command here!").click();

    // entering a keyword into the search bar again
    await page.getByPlaceholder("Enter command here!").fill("csci");

    // entering the query
    await page.getByLabel("Query Submit Button").click();

    // making sure a result is produced
    await expect(page.getByText("Recommended Courses For Keyword: visa ✿ ʕ •ᴥ•ʔ")).toBeVisible();
    await expect(page.getByText(string)).toBeVisible();
    let string2 = "You've Reached The End Of Our Recommended Courses for the Keyword: csci ᕦʕ •`ᴥ•´ʔᕤ"
    await expect(page.getByText("Recommended Courses For Keyword: csci ✿ ʕ •ᴥ•ʔ")).toBeVisible();
    await expect(page.getByText(string2)).toBeVisible();
})

test("successfully able to make a query based on day, time, a course, and a keyword", async ({page}) => {
    await page.goto(url);

    // making sure the Monday, Wednesday, and Friday buttons are visible
    await expect(page.getByLabel('Monday Button')).toBeVisible();
    await expect(page.getByLabel('Wednesday Button')).toBeVisible();
    await expect(page.getByLabel('Friday Button')).toBeVisible();

    // clicking on the Monday button
    await page.getByLabel("Monday Button").click();
    await page.getByLabel("Wednesday Button").click();
    await page.getByLabel("Friday Button").click();

    // making sure the early morning and afternoon buttons are visible
    await expect(page.getByText('Early Morning')).toBeVisible();
    await expect(page.getByText('Afternoon')).toBeVisible();

    // clicking on the early morning and afternoon buttons
    await page.getByText('Early Morning').click();
    await page.getByText('Afternoon').click();

    // selecting a course via the drop downs
    await page.locator("#department").selectOption({label: "CSCI"});
    await page.locator("#course").selectOption({label: "CSCI 0320"});

    // adding the course to the course history
    await expect(page.getByLabel("Past Course Submit Button")).toBeVisible();
    await page.getByLabel("Past Course Submit Button").click();

    // clicking on the search bar
    await page.getByPlaceholder("Enter command here!").click();

    // entering a keyword into the search bar
    await page.getByPlaceholder("Enter command here!").fill("art");

    // entering the query
    await page.getByLabel("Query Submit Button").click();

    // making sure a result is produced
    await expect(page.getByText("Recommended Courses For Keyword: art ✿ ʕ •ᴥ•ʔ")).toBeVisible();
    let string = "You've Reached The End Of Our Recommended Courses for the Keyword: art ᕦʕ •`ᴥ•´ʔᕤ"
    await expect(page.getByText(string)).toBeVisible();
})

test("successfully make a query, and look into the output table", async ({page}) => {
    await page.goto(url);

    // clicking on the search bar
    await page.getByPlaceholder("Enter command here!").click();

    // entering a keyword into the search bar
    await page.getByPlaceholder("Enter command here!").fill("7 hours");

    // entering the query
    await page.getByLabel("Query Submit Button").click();

    // checking the table for the courses
    await expect(page.getByRole('cell', { name: 'Department' })).toBeVisible();
    await expect(page.getByRole('cell', { name: 'Class Name' })).toBeVisible();
    await expect(page.getByRole('cell', { name: 'CourseCode' })).toBeVisible();
    await expect(page.getByRole('cell', { name: 'Description' })).toBeVisible();
    await expect(page.getByRole('cell', { name: 'Restrictions' })).toBeVisible();
    await expect(page.getByRole('cell', { name: 'Meeting Times' })).toBeVisible();
    await expect(page.getByRole('cell', { name: 'Similarity Score' })).toBeVisible();

    await expect(page.getByRole('cell', { name: 'AMST', exact: true})).toBeVisible();
    let desc = '7 Hours and 55 Minutes: Sex, Work, and Migration in Global Contexts'
    await expect(page.getByRole('cell', { name: desc })).toBeVisible();
    await expect(page.getByRole('cell', { name: 'AMST 0090A' })).toBeVisible();
    let desc2 = "diving into global debates, surround gender, sex, migration, and labor," + 
    " this course considers forms of work that are inflected by race, gender, class, nation," + 
    " and ability. our course title, “7 hours and 55 minutes,” draws its inspiration from an" + 
    " advocacy game developed by the empower foundation, thailand’s first sex worker rights organization." + 
    " the game asks participants to consider thai sex worker understandings an of sex work, within the" + 
    " context of an 8 hour working day. it examines how the global legal and civilian regulation of gendered" + 
    " bodies is met with vital forms of resistance and community organizing. each week, our seminar will" + 
    " explore one book, article, documentary film, cultural artifact, or the mixed media artistic productions."
    await expect(page.getByRole('cell', { name: desc2 })).toBeVisible();
    let desc3 = "Enrollment limited to students with a semester level of 01 or 02." + 
    " Enrollment is limited to Undergraduate level students."
    await expect(page.getByRole('cell', { name: desc3 })).toBeVisible();
    await expect(page.getByRole('cell', { name: 'M 3-5:30p' })).toBeVisible();
    await expect(page.getByRole('cell', { name: '0.015625' })).toBeVisible();

    await expect(page.getByText("Recommended Courses For Keyword: 7 hours ✿ ʕ •ᴥ•ʔ")).toBeVisible();
    let string = "You've Reached The End Of Our Recommended Courses for the Keyword: 7 hours ᕦʕ •`ᴥ•´ʔᕤ"
    await expect(page.getByText(string)).toBeVisible();
}) 


