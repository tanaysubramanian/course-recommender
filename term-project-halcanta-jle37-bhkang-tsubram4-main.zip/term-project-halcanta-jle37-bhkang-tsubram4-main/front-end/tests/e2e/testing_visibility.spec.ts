import {expect, test} from "@playwright/test"

const url = "http://localhost:8000"

test("successfully able to navigate to URL and selection features are visible", async ({page}) => {
    await page.goto(url);

    // making sure text is visible
    await expect(page.getByText('Please select preferred days/times')).toBeVisible();

    // making sure buttons corresponding to days of the week are visible
    await expect(page.getByLabel('Monday Button')).toBeVisible();
    await expect(page.getByLabel('Tuesday Button')).toBeVisible();
    await expect(page.getByLabel('Wednesday Button')).toBeVisible();
    await expect(page.getByLabel('Thursday Button')).toBeVisible();
    await expect(page.getByLabel('Friday Button')).toBeVisible();

    // making sure buttons corresponding to times of day are visible
    await expect(page.getByText('Early Morning')).toBeVisible();
    await expect(page.getByText('Afternoon')).toBeVisible();
    await expect(page.getByText('Early Evening')).toBeVisible();
    await expect(page.getByText('Late Evening')).toBeVisible();

    // making sure text is visible
    await expect(page.getByText('Would you like to find courses that have the same professor?')).toBeVisible();

    // making sure "yes" selection button is visible
    await expect(page.getByText('Yes')).toBeVisible();

    // making sure department and course code dropdowns are visible
    await expect(page.getByLabel('Department')).toBeVisible();
    await expect(page.getByLabel('Course Code')).toBeVisible();

    // making sure the search bar is visible
    await expect(page.getByLabel('Searchbar')).toBeVisible();

    // making sure the "submit" button is visible
    await expect(page.getByLabel("Query Submit Button")).toBeVisible();

    // making sure the "reset history" button is visible
    await expect(page.getByLabel("Clear History Button")).toBeVisible();

    // making sure the "add course" button is visible
    await expect(page.getByLabel("Past Course Submit Button")).toBeVisible();

    // making sure the "clear courses" button is visible
    await expect(page.getByLabel("Clear Courses Button")).toBeVisible();
})