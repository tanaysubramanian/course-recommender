/**
 * function to connect the front-end and back-end, passes url with user inputs
 * to the server and calls the similarity algorithm and returns output with 
 * the proper courses populated. Contains a catch in cases fetching fails.
 */
export async function courseFinder(keyword : string, pCourse : string, bool : string, days : string[], times : string[]): Promise<Array<Array<string>>> {
    let weekDays = "";
    let weekTimes = ""
    // "_" are used to distinguish between different checked values
    for (var i = 0; i < days.length; i++) {
        weekDays = weekDays + days[i] + "_";
    }
    for (var j = 0; j < times.length; j++) {
        weekTimes = weekTimes + times[i] + "_";
    }
    // full url with user queries
    const link = "http://localhost:3232/courseSearch?keyword=" + keyword + "&pastCourses=" + pCourse + "&prioritizeQuery=" + bool + "&dayOfWeek=" + weekDays + "&timesOfWeek=" + weekTimes;
    console.log(link);
    return await fetch(link).then((response) => response.json()).then((json) => {
        if (json.result === "success") {
            return json.info
        }
    }).catch((error) => {return "Error in fetch"})
}