import { useState } from "react";
import { CourseHistory } from "./CourseHistory";
import REPLInput from "./REPLInput";


/**
 * Function REPl initializes and calls REPLInput and CourseHistory to populate page
 */
export default function REPL() {
    const [history, setHistory] = useState<string[]>([]);

    return (
        <div className="repl">
            <REPLInput
            history={history}
            setHistory={setHistory}/>
            <CourseHistory history={history}/>
            <hr></hr>
        </div>
    )
}