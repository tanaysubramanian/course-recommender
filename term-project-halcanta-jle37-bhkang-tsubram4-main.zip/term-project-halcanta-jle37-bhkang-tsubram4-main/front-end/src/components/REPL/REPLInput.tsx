import { useState,Dispatch,SetStateAction, useEffect} from 'react';
import {SearchBar} from "../SelectionFeatures/SearchBar";
import '../../styles/main.css';
import Dropdown from '../SelectionFeatures/Dropdown';
import {DropdownProps} from '../SelectionFeatures/Dropdown';
import Checkbox from "../SelectionFeatures/Checkbox";
import {courseFinder} from "../../utils/api"

/**
 * Props for REPLInput - contains a tuple that accepts a 
 * string as a command and an array of array of strings 
 * as an output as well as a setter, used to maintain state
 */
interface REPLInputProps {
 history : {command : string; result: string[][] }[];
 setHistory: Dispatch<SetStateAction<{ command: string; result: string[][] }[]>>;
}


export default function REPLInput(props: REPLInputProps) {
 // Shared states for user keyword input, departments selected, 
 // course codes selected, previous courses inputed, days 
 // selected, times selected, and whether or not the user 
 // wishes to prioritize professors
 const [searchString, setSearchString] = useState<string>("");
 const [checkedDepartment, setCheckedDepartment] = useState<string>("");
 const [checkedCourseCode, setCheckedCourseCode] = useState<string>("");
 const [checkedCourse, setCheckedCourse] = useState<string>("");
 const [checkedDays, setCheckedDays] = useState<string[]>([]);
 const [checkedTimes, setCheckedTimes] = useState<string[]>([]);
 const [checkedPreferences, setCheckedPreferences] = useState<string>("false");


 // Click handler for our Submit button - makes a call to courseFinder 
 // and returns a list of matching courses. The array of courses along 
 // with the keyword string are added and passed in to props.history
 async function handleSubmit(searchString: string) {
   let value = await courseFinder(searchString, checkedCourse, checkedPreferences, checkedDays, checkedTimes);
   const toAddHistory = {command: searchString, result: value};
   props.setHistory([...props.history, toAddHistory])
   setSearchString("");
 }

 // Click handler for clearing REPL History (should clear all displayed courses)
 function handleClear() {
   props.setHistory([]);
 }

 // Click handler for adding a previously taken course - user is allowed 
 // to input several past courses to compare with the database
 function createPastCourse() {
   setCheckedCourse(checkedCourseCode.toLowerCase() + "_");
 }

 // Click handler for clearing past courses
 // checkedCourses will be set to an empty string
 function clearPastCourses() {
   setCheckedCourse("");
 }

 // Accessiblity shortcuts
 // Use the control key + the shift key in order to highlight the search bar
 // Use the enter key in order to submit a query
 useEffect(() => {
    
  const keyPress = (event : KeyboardEvent) => {
    if (event.ctrlKey && event.shiftKey) {
      const inputBox = document.querySelector(".repl-command-box") as HTMLElement;
      inputBox.focus();
    } else if (event.key === "Enter") {
      const inputBox = document.querySelector(".repl-command-box") as HTMLElement;
      inputBox.blur();
      handleSubmit(searchString);
    }
  }
  
  window.addEventListener("keydown", keyPress);

  return () => {
    window.removeEventListener("keydown", keyPress);
  };
  
}, [searchString]);


 return (
   <div className="repl-input"> 
     <div>
     <Checkbox
     checkedDays={checkedDays}
     setCheckedDays={setCheckedDays}
     checkedTimes={checkedTimes}
     setCheckedTimes={setCheckedTimes}
     checkedPreferences={checkedPreferences}
     setCheckedPreferences={setCheckedPreferences}
     ></Checkbox>
     </div>
     <div>
     <Dropdown
     checkedDepartment={checkedDepartment}
     setCheckedDepartment={setCheckedDepartment}
     checkedCourseCode={checkedCourseCode}
     setCheckedCourseCode={setCheckedCourseCode}>
     </Dropdown>
     </div>
     <fieldset>
       <legend> Enter search parameter :3</legend>
       <SearchBar
       value={searchString}
       setValue={setSearchString}
       ariaLabel={'Searchbar'}
       />
     </fieldset>
     <div className="button-container">
       <div className="submit-buttons">
           <button
           aria-label={"Query Submit Button"}
           onClick={() => handleSubmit(searchString)}>
             Submit
         </button>
         <button
           aria-label={"Clear History Button"}
           onClick={() => handleClear()}>
             Reset History
         </button>
       </div>
       <div className="submit-buttons">
         <button
         aria-label={"Past Course Submit Button"}
         onClick={() => createPastCourse()}>
             Add To Course History
         </button>
         <button
         aria-label={"Clear Courses Button"}
         onClick={() => clearPastCourses()}>
             ClearCourses
         </button>
     </div>
     </div>
   </div>
 );
}
