import { useEffect, useRef } from "react";
import { getSuggestions } from "../SelectionFeatures/DisplayCourses"

/**
 * History will be stored as a tuple that accepts a 
 * string as a command and an array of array of strings 
 */
interface CourseHistoryProps {
    history: { command: string; result: string[][] }[];
}

/**
 * CourseHistory updates page history to be displayed - uses CourseHistoryProps 
 * and getSuggestions to format the proper list of matching courses
 */
export function CourseHistory(props: CourseHistoryProps) {
    const scrollableRef = useRef<HTMLDivElement>(null);

    // Accessiblity shortcut
    // You can use the down and up arrow keys in order to look through the course recommendations
    useEffect(() => {
    const keyPress = (event : KeyboardEvent) => {
      if (event.key === "ArrowDown" && scrollableRef.current) {
        event.preventDefault();
        scrollableRef.current.scrollTop += 50;
      }
      if (event.key === "ArrowUp" && scrollableRef.current) {
        event.preventDefault();
        scrollableRef.current.scrollTop -= 50;
      }
    }
  
    window.addEventListener("keydown", keyPress);

    return () => {
      window.removeEventListener("keydown", keyPress);
   }
  }, [props.history])
    console.log(props.history);
    return props.history.map((command, index) =>
    <div>
        <h2>Recommended Courses For Keyword: {command["command"]} ✿ ʕ •ᴥ•ʔ</h2>
        {getSuggestions(command["result"], index)}
        <h2>You've Reached The End Of Our Recommended Courses for the Keyword: {command["command"]} ᕦʕ •`ᴥ•´ʔᕤ</h2>
    </div>
      );
}