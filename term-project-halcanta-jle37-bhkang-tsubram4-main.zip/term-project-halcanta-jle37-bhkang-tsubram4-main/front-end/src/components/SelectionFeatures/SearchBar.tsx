// import '../styles/main.css';
import { Dispatch, SetStateAction } from 'react';

/**
 * SearchBarProps contains a string value, a setter, and an aria-label
 */
interface SearchBarProps {
    value: string, 
    // This type comes from React+TypeScript. VSCode can suggest these.
    // Concretely, this means "a function that sets a state containing a string"
    setValue: Dispatch<SetStateAction<string>>,
    ariaLabel: string 
  }
  
  /**
   * function that takes in components from SearchBarProps 
   * and creates an input box based on the assignments given
   */
  export function SearchBar({value, setValue, ariaLabel}: SearchBarProps) {
    return (
      <input type="text" 
            className="repl-command-box"
            value={value} 
            placeholder="Enter command here!"
            onChange={(ev) => setValue(ev.target.value)}
            aria-label={ariaLabel}>
      </input>
    );
  }