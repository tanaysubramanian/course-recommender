import React, { Dispatch, SetStateAction, useState, useEffect } from "react";
import db from '../../utils/firebaseConfig'
import { collection, getDocs, query } from "firebase/firestore";

export interface DropdownProps {
    checkedDepartment : string;
    setCheckedDepartment : Dispatch<SetStateAction<string>>;
    checkedCourseCode : string;
    setCheckedCourseCode : Dispatch<SetStateAction<string>>;
}

// Mocked Departments and CourseCodes used for early testing
const mockedDeptCourses = {
  "ARAB": ["ARAB 0100","ARAB 300"],
  "CSCI": ["CSCI 200","CSCI 320","CSCI 1470","CSCI 1530"],
  "MATH": ["MATH 0090", "MATH 0100"],
  "APMA": ["APMA 1650", "APMA 300"]
};

// All Departments listed on CAB for Fall 2024 fetched from firestore
const listOfAllDepts = ['AFRI', 'AMST', 'ANTH', 'APMA', 'ARAB', 'ARCH', 'ARTS', 'ASYR', 'BIOL', 'CHEM', 'CHIN', 'CLAS', 'CLPS', 'COLT', 'COST', 'CSCI', 'CZCH', 'DATA', 'EAST', 'ECON', 'EDUC', 'EEPS', 'EGYT', 'EINT', 'EMOW', 'ENGL', 'ENGN', 'ENVS', 'ETHN', 'FREN', 'GNSS', 'GPHP', 'GREK', 'GRMN', 'HCL', 'HEBR', 'HIAA', 'HISP', 'HIST', 'HMAN', 'HNDI', 'IAPA', 'ITAL', 'JAPN', 'JUDS', 'KREA', 'LACA', 'LANG', 'LATN', 'LING', 'LITR', 'MATH', 'MCM', 'MDVL', 'MES', 'MGRK', 'MPA', 'MUSC', 'NAHU', 'NAIS', 'NEUR', 'PHIL', 'PHP', 'PHUM', 'PHYS', 'PLME', 'PLSH', 'POBS', 'POLS', 'PRSN', 'RELS', 'RUSS', 'SANS', 'SAST', 'SIGN', 'SLAV', 'SOC', 'STS', 'TAPS', 'TKSH', 'UNIV', 'URBN', 'VIET', 'VISA', 'YORU']

/**
 * const Dropdown displays available departments and conditionally generates course codes based on selected department
 */
const Dropdown: React.FC<DropdownProps>  = ({ checkedDepartment, setCheckedDepartment, checkedCourseCode, setCheckedCourseCode }) => {
    const [availableCourses, setAvailableCourses] = useState<string[]>([]);

    useEffect(() => {
        if (!checkedDepartment) {
            setAvailableCourses([]);
            return;
        }
        const fetchCourses = async() => {
            const courseCollection = collection(db, checkedDepartment);
            const courseQuery = query(courseCollection);
            const querySnapshot = await getDocs(courseQuery);
            const courses = querySnapshot.docs.map(doc=> doc.id);
            setAvailableCourses(courses);
        };
        fetchCourses();
    }, [checkedDepartment]);

    return (
        <div className="dropdown">
            <label>
                Department
                <select id="department" value={checkedDepartment} onChange={e => setCheckedDepartment(e.target.value)}>
                    <option value="">Select Department</option>
                    {listOfAllDepts.map(dept => (
                        <option key={dept} value={dept}>{dept}</option>
                    ))}
                </select>
            </label>
            <label>
                Course Code
                <select id="course" value={checkedCourseCode} onChange={e => setCheckedCourseCode(e.target.value)}>
                    <option value="">Select Course</option>
                    {availableCourses.map(course => (
                        <option key={course} value={course}>{course}</option>
                    ))}
                </select>
            </label>
        </div>
    )
}

export default Dropdown;