/**
 * function getSuggestions takes in the filtered course information and generates 
 * a table to display the matching courses (called in courseHistory)
 */
 export function getSuggestions(parameter: string[][], index: number) {
    const csvToBeLoaded = parameter
    const tableContent = csvToBeLoaded.map((parameter, index) => {
        return (
        <table aria-label={"Course Table"} align="center">
            {/** Table Headers */}
            <thead>
                <tr>
                    <th>Department</th>
                    <th>Class Name</th>
                    <th>CourseCode</th>
                    <th>Description</th>
                    <th>Restrictions</th>
                    <th>Meeting Times</th>
                    <th>Similarity Score</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    {parameter.map((item) => (
                        <td>{item}</td>
                    ))}
                </tr>
            </tbody>
        </table>);
        });
 
 
    return tableContent;
 }
 