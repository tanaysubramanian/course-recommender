import React from "react";
import {useState, Dispatch, SetStateAction} from "react"

/**
 * Props for checkboxes divided by category of day of the week, 
 * meeting times, and a preference to prioritize professors
 */
interface CheckboxProps {
    checkedDays : string[]; 
    setCheckedDays: Dispatch<SetStateAction<string[]>>;
    checkedTimes: string[];
    setCheckedTimes: Dispatch<SetStateAction<string[]>>;
    checkedPreferences : string;
    setCheckedPreferences: Dispatch<SetStateAction<string>>;
}

/**
 * const Checkbox generates a series of checkboxes relating to the three categories above
 */
const Checkbox = (props: CheckboxProps) => {

    /**
     * Handler to add a new day to the user's checked days. Day will 
     * only be added if props.checkedDays does not already contain it.
     */
    function handleCheckedDays(e : any) {
        if (props.checkedDays.includes(e.target.value)) {
            props.checkedDays.splice(props.checkedDays.indexOf(e.target.value));
        } else {
            props.setCheckedDays([...props.checkedDays, e.target.value]);
        }
    }
    // Console.log added to help user see props.checkedDays is populated
    console.log(props.checkedDays);

    /**
     * Handler to add a new day to the user's checked times. Time will 
     * only be added if props.checkedTimes does not already contain it.
     */
    function handleCheckedTimes(e : any) {
        if (props.checkedTimes.includes(e.target.value)) {
            props.checkedTimes.splice(props.checkedTimes.indexOf(e.target.value));
        } else {
            props.setCheckedTimes([...props.checkedTimes, e.target.value]);
        }
    }
    // Console.log added to help user see props.checkedTimes is populated
    console.log(props.checkedTimes);

    /**
     * Handler to set user's preference for Professor priority
     */
    function handleCheckedPreferences(e : any) {
       props.setCheckedPreferences(e.target.value);
    }
    // Console.log added to help user see props.checkedPreferences had the proper value
    console.log(props.checkedPreferences);

    return (
        <div className="checkbox">
            {/** checkboxes for selected days (Monday - Friday) */}
            <h4>Please select preferred days/times</h4>
            <div>
                <input value = "M" type = "checkbox" onChange={handleCheckedDays}/>
                    <div aria-label="Monday Button" className="tooltip">Mon
                        <span className="tooltiptext top">Monday</span>
                    </div>
                <input value = "T" type = "checkbox" onChange={handleCheckedDays}/>
                    <div aria-label="Tuesday Button" className="tooltip">Tues
                        <span className="tooltiptext top">Tuesday</span>
                    </div>
                <input value = "W" type = "checkbox" onChange={handleCheckedDays}/>
                    <div aria-label="Wednesday Button" className="tooltip">Wed
                        <span className="tooltiptext top">Wednesday</span>
                    </div>
                <input value = "Th" type = "checkbox" onChange={handleCheckedDays}/>
                    <div aria-label="Thursday Button" className="tooltip">Thurs
                        <span className="tooltiptext top">Thursday</span>
                    </div>
                <input value = "F" type = "checkbox" onChange={handleCheckedDays}/>
                    <div aria-label="Friday Button" className="tooltip">Fri
                        <span className="tooltiptext top">Friday</span>
                    </div>
            </div>

            {/** checkboxes for selected class times (8am - 9pm) */}
            <div>
            <input value = "Before 12pm" type = "checkbox" onChange={handleCheckedTimes}/>
                <div className="tooltip">Early Morning
                    <span className="tooltiptext bottom">Before 12pm</span>
                </div>
            <input value = "12pm-4pm" type = "checkbox" onChange={handleCheckedTimes}/>
                <div className="tooltip">Afternoon
                    <span className="tooltiptext bottom">12pm-4pm</span>
                </div>
            <input value = "4pm-6pm" type = "checkbox" onChange={handleCheckedTimes}/>
                <div className="tooltip">Early Evening
                    <span className="tooltiptext bottom">4pm-6pm</span>
                </div>
            <input value = "After 6pm" type = "checkbox" onChange={handleCheckedTimes}/>
                <div className="tooltip">Late Evening
                    <span className="tooltiptext bottom">After 6pm</span>
                </div>
            </div>

            {/** checkbox for professor priority */}
            <div id="prof">
            <label htmlFor="prof">Would you like to find courses that have the same professor?</label>
            <input value = "true" type = "checkbox" onChange={handleCheckedPreferences}/>
                <div className="tooltip">Yes
                    <span className="tooltiptext right">Will add priority to courses taught by the same professor</span>
                </div>
            </div>
        </div>
)}

export default Checkbox;
