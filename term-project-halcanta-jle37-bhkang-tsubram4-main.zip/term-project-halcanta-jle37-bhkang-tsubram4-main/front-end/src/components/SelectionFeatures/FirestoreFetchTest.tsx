import React, { useEffect, useState, FC } from "react";
import db from "../../utils/firebaseConfig";
import { collection, getDocs } from "firebase/firestore";

/**
 * const FirestoreFetchTest fetches and loads codes corresponding 
 * to a user's selected department from CAB using Firetore
 */
const FirestoreFetchTest: React.FC = () => {
    console.log("Component mounted");
    const [courses, setCourses] = useState<string[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        console.log("useEffect called");

        const fetchCourses = async () => {
            try {
                console.log("Fetching courses...");
                const querySnapshot = await getDocs(collection(db, "CSCI"));
                console.log("Documents fetched:", querySnapshot.docs.length);
                const fetchedCourses = querySnapshot.docs.map(doc => doc.id);
                setCourses(fetchedCourses);
            } catch (error) {
                console.error("Error fetching data:", error);
            } finally {
                setLoading(false);
            }
        };

        // catch staement for an error in fetching
        fetchCourses().catch(error => {
            console.error("Failed to fetch courses:", error);
            setLoading(false);
        });
    }, []);

    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            {/* <h1>Courses in CSCI</h1> */}
            {/* {courses.length > 0 ? (
                <ul>
                    {courses.map(course => (
                        <li key={course}>{course}</li>
                    ))}
                </ul>) : (<p>No courses found.</p>)
            } */}
        </div>
    );};

export default FirestoreFetchTest;
